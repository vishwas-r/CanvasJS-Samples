1. Extract the Project to a folder.
2. Open the project in VS Code.
3. Install the packages by running 'flutter packages get' command.
4. Build & Run the Project by running 'flutter run' command.